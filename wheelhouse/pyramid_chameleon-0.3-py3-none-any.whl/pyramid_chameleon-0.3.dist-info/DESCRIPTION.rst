Chameleon templating system Bindings for Pyramid
=================================================

These are bindings for the `Chameleon templating system
<http://pagetemplates.org/>`_ for the Pyramid_ web framework.  See
http://docs.pylonsproject.org/projects/pyramid_chameleon/en/latest/ for
documentation.

.. _Pyramid: http://pylonsproject.org/


0.3 (2014-07-01)
----------------

- Remove dependency on ``pyramid.interfaces.ITemplateRenderer`` (which is
  deprecated in Pyramid > 1.5).

- Update Trove classifiers and tests to support Python 3.4.

0.2 (2014-02-09)
----------------

- Dropped dependency on ``nose-selecttests``.

0.1 (2013-09-07)
----------------

-  Initial version


