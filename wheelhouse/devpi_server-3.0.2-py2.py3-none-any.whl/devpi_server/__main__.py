import devpi_server.main

if __name__ == "__main__":
    devpi_server.main.main()
