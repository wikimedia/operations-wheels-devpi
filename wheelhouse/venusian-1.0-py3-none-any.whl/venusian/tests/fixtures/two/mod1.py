from venusian.tests.fixtures import decorator

@decorator()
class Class(object):
    pass
