``pkginfo`` README
==================

This package provides an API for querying the distutils metadata written in
the ``PKG-INFO`` file inside a source distriubtion (an ``sdist``) or a
binary distribution (e.g., created by running ``bdist_egg``).  It can
also query the ``EGG-INFO`` directory of an installed distribution, and
the ``*.egg-info`` stored in a "development checkout"
(e.g, created by running ``setup.py develop``).


Please see the `pkginfo docs <http://packages.python.org/pkginfo>`_
for detailed documentation.


``pkginfo`` Changelog
=====================

1.2.1 (2014-01-02)
------------------

- Add overlooked Trove classifier for Python 3.4.

1.2 (2014-01-02)
----------------

- Add support for Python 3.4, PyPy3.

- Add 100% coverage for ``pkginfo.commandline`` module.

1.2b1 (2013-12-05)
------------------

- Add support for the "wheel" distribution format, along with minimal
  metadata 2.0 support (not including new PEP 426 JSON properties).
  Code (re-)borrowed from Donald Stuft's ``twine`` package.

1.1 (2013-10-09)
----------------

- Fix tests to pass with current PyPy releases.

1.1b1 (2013-05-05)
------------------

- Support "develop" packages which keep their ``*.egg-info`` in a subdirectory.
  See https://bugs.launchpad.net/pkginfo/+bug/919147.

- Add support for "unpacked SDists" (thanks to Mike Lundy for the patch).

1.0 (2013-05-05)
----------------

- No changes from 1.0b2.

1.0b2 (2012-12-28)
------------------

- Suppress resource warning leaks reported against clients.

- Fix 'commandline' module under Py3k.

1.0b1 (2012-12-28)
------------------

- Add support for Python 3.2 and 3.3, including testing them under ``tox``.

- Add support for PyPy, including testing it under ``tox``.

- Test supported Python versions under ``tox``.

- Drop support for Python 2.5.

- Add a ``setup.py dev`` alias:  runs ``setup.py develop`` and installs
  testing extras (``nose`` and ``coverage``).

0.9.1 (2012-10-22)
------------------

- Fix test failure under Python >= 2.7, which is enforcing
  'metadata_version == 1.1' because we have classifiers.


0.9 (2012-04-25)
----------------

- Fix introspection of installed namespace packages.
  They may be installed as eggs or via dist-installed 'egg-info' files.
  https://bugs.launchpad.net/pkginfo/+bug/934311

- Avoid a regression in 0.8 under Python 2.6 / 2.7 when parsing unicode.
  https://bugs.launchpad.net/pkginfo/+bug/733827/comments/3


0.8 (2011-03-12)
----------------

- Work around Python 2.7's breakage of StringIO.  Fixes
  https://bugs.launchpad.net/pkginfo/+bug/733827

- Fix bug in introspection of installed packages missing the
  ``__package__`` attribute.


0.7 (2010-11-04)
----------------

- Preserve newlines in the ``description`` field.  Thanks to Sridhar
  Ratnakumar for the patch.

- 100% test coverage.


0.6 (2010-06-01)
----------------

- Replace use of ``StringIO.StringIO`` with ``io.StringIO``, where available
  (Python >= 2.6).

- Replace use of ``rfc822`` stdlib module with ``email.parser``, when
  available (Python >= 2.5).  Ensured that distributions "unfold" wrapped
  continuation lines, stripping any leading / trailing whitespace, no matter
  which module was used for parsing.

- Remove bogus testing dependency on ``zope.testing``.

- Add tests that the "environment markers" spelled out in the approved
  PEP 345 are captured.

- Add ``Project-URL`` for ``1.2`` PKG-INFO metdata (defined in the accepted
  version of PEP 345).


0.5 (2009-09-11)
----------------

- Marked package as non-zip-safe.

- Fix Trove metadata misspelling.

- Restore compatibility with Python 2.4.

- Note that the introspection of installed packages / modules works only
  in Python 2.6 or later.

- Add ``Index`` class as an abstraction over a collection of distributions.

- Add ``download_url_prefix`` argument to ``pkginfo`` script.  If passed,
  the script will use the prefix to synthesize a ``download_url`` for
  distributions which do not supply that value directly.


0.4.1 (2009-05-07)
------------------

- Fix bugs in handling of installed packages which lack ``__file__``
  or ``PKG-INFO``.


0.4 (2009-05-07)
----------------

- Extend the console script to allow output as CSV or INI.  Also, added
  arguments to specify the metadata version and other parsing / output
  policies.

- Add support for the different metadata versions specified in PEPs
  241, 314, and 345.  Distributions now parse and expose only the attributes
  corresponding to their metadata version, which defaults to the version
  parsed from the ``PKG-INFO`` file.  The programmer can override that version
  when creating the distribution object.


0.3 (2009-05-07)
----------------

- Add support for introspection of "development eggs" (checkouts with
  ``PKG-INFO``, perhaps created via ``setup.py develop``).

- Add a console script, ``pkginfo``, which takes one or more paths
  on the command line and writes out the associated information.  Thanks
  to ``runeh`` for the patch!

- Add ``get_metadata`` helper function, which dispatches a given path or
  module across the available distribution types, and returns a distribution
  object.  Thanks to ``runeh`` for the patch!

- Make distribution objects support iteration over the metadata fields.
  Thanks to ``runeh`` for the patch!

- Make ``Distribution`` and subclasses new-style classes.  Thanks to ``runeh``
  for the patch!


0.2 (2009-04-14)
----------------

- Add support for introspection of ``bdist_egg`` binary distributions.


0.1.1 (2009-04-10)
------------------

- Fix packaging errors.


0.1 (2009-04-10)
----------------

- Initial release.


