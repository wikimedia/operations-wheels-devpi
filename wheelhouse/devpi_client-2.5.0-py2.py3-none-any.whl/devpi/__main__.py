if __name__ == "__main__":
    from devpi import main
    main.main()
